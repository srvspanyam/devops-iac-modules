#!/bin/bash
sudo su -
sudo service mesos-slave stop

layer=${name}
fasak=${fasak}
region=${region}
envname=${environment}
hosted_zone_id=${hosted_zone_id}
token_id=${token_id}
instance_type=${instance_type}
access_key=${access_key}
secret_key=${secret_key}
domainname=${domain}
profile=${profile}
pip=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)
# change the dots by hyphen in pip string
# pipfrmt=$(echo "$pip" | tr '.' '-') 
# instance_id=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)

hstname="$layer$fasak$domainname"
shrtname="$layer$fasak"
# n_cpu=$(awk "BEGIN {print int(0.85 * $(nproc))}")

# mem=$(free -g | awk '/Mem/ {print int($2 * 0.85)}')
# mem_res=$((mem * 1024))

echo $pip $hstname $layer$fasak >> /etc/hosts
echo $hstname > /etc/hostname
hostname=`cat /etc/hostname`
hostnamectl set-hostname $hostname
cat /etc/hostname > /etc/mesos-slave/hostname
# attribute="cloud_provider:aws;aws-opsws-layer:$layer;layer:$layer;instance_type:$instance_type;location:$region;update-domain:1;fault-domain:1;aws-ec2-vcpus:$n_cpu;aws-ec2-mem:$mem"
# resource="ports(*):[8000-9000, 20001-32000];cpus:$n_cpu;mem:$mem_res"
# echo $resource > /etc/mesos-slave/resources
# # echo $attribute > /etc/mesos-slave/attributes
# curl "https://s3.amazonaws.com/aws-cli/awscli-bundle-1.16.312.zip" -o "awscli-bundle.zip" 
# sudo apt install unzip 
# unzip awscli-bundle.zip
# sudo ./awscli-bundle/install -i /usr/local/aws -b /usr/local/bin/aws
# sudo aws configure set aws_access_key_id $access_key
# sudo aws configure set aws_secret_access_key $secret_key
# export AWS_PROFILE=${profile}
# sudo aws configure set region $region
# sudo echo '''{ "Comment": "CREATE a record ", "Changes": [{ "Action": "CREATE", "ResourceRecordSet": { "Name": "'$hstname'", "Type": "A", "TTL": 300, "ResourceRecords": [{ "Value": "'$pip'"}] }}] }'''> /sample.json
# sudo aws route53 change-resource-record-sets --hosted-zone-id $hosted_zone_id --change-batch file:///sample.json
# sudo service apache2 restart
# sudo curl localhost:80/config_puller/bootstrap/ --header "TOKEN-ID:$token_id"
# (sudo crontab -l ; sudo echo "0 0 * * 1  /usr/bin/docker system prune -af") | sudo crontab -
# sudo service cron reload
# sudo rm -rf /data/mesos/meta/slaves/
# sudo service docker restart
# sudo systemctl enable mesos-slave
# sudo service mesos-slave restart
sudo systemctl restart telegraf
# sudo systemctl restart newrelic-infra
sudo systemctl restart mesos-master
service marathon restart
