#!/bin/bash
sudo su -

layer=${name}
region=${region}
envname=${environment}
hosted_zone_id=${hosted_zone_id}
token_id=${token_id}
instance_type=${instance_type}
access_key=${access_key}
secret_key=${secret_key}
domainname=${domain}

# change the dots by hyphen in pip string
pip=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)
pipfrmt=$(echo "$pip" | tr '.' '-') 
# instance_id=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
hstname="$layer-$pipfrmt$domainname"
shrtname="$layer-$pipfrmt"

# n_cpu=$(awk "BEGIN {print int(0.85 * $(nproc))}")

# mem=$(free -g | awk '/Mem/ {print int($2 * 0.85)}')
# mem_res=$((mem * 1024))

echo $pip $hstname $layer$pipfrmt >> /etc/hosts
echo $hstname > /etc/hostname
hostname=`cat /etc/hostname`
hostnamectl set-hostname $hostname

# resolv_conf="nameserver 10.111.15.248
# nameserver 10.111.0.2
# search ap-south-1.compute.internal
# search anon-ci.bheem.net"

# echo "$resolv_conf" > /etc/resolv.conf
if [ "$layer" == "mlb-corp" ]; then
    sed -i -e 's/--group internal/--group marathonlb-corp/g' /etc/systemd/system/marathon-lb.service
elif [ "$layer" == "mlb-ext" ]; then
    sed -i -e 's/--group internal/--group external/g' /etc/systemd/system/marathon-lb.service
fi

# AWS_ACCESS_KEY_ID=$access_key AWS_SECRET_ACCESS_KEY=$secret_key aws ec2 create-tags --resources $instance_id --region $region  --tags "Key"="Name","Value"=$shrtname

# curl "https://s3.amazonaws.com/aws-cli/awscli-bundle-1.16.312.zip" -o "awscli-bundle.zip" 
# unzip awscli-bundle.zip
# sudo ./awscli-bundle/install -i /usr/local/aws -b /usr/local/bin/aws

# sudo aws configure set aws_access_key_id $access_key
# sudo aws configure set aws_secret_access_key $secret_key
# sudo aws configure set region $region

# sudo echo '''{ "Comment": "CREATE a record ", "Changes": [{ "Action": "CREATE", "ResourceRecordSet": { "Name": "'$hstname'", "Type": "A", "TTL": 300, "ResourceRecords": [{ "Value": "'$pip'"}] }}] }'''> /sample.json
# sudo aws route53 change-resource-record-sets --hosted-zone-id $hosted_zone_id --change-batch file:///sample.json
# aws ec2 create-tags --resources $instance_id --tags Key=Name,Value=$shrtname --region $region

# sudo service apache2 restart
# sudo curl localhost:80/config_puller/bootstrap/ --header "TOKEN-ID:$token_id"

# (sudo crontab -l ; sudo echo "0 * * * * systemctl restart haproxy") | sudo crontab -
# (sudo crontab -l ; sudo echo "1 0 * * * /usr/bin/find /haproxylog/ -type f -name '*.log' -mtime +1 -exec rm -fv {} \;") | sudo crontab -    
# (sudo crontab -l ; sudo echo "0 0 * * 1  /usr/bin/docker system prune -af") | sudo crontab -
# sudo service cron reload

sudo systemctl daemon-reload
sudo systemctl restart haproxy
sudo systemctl restart marathon-lb.service
sudo systemctl restart haproxy_exporter.service
sudo systemctl restart hapreloadcount
sudo systemctl restart telegraf
sudo systemctl restart newrelic-infra