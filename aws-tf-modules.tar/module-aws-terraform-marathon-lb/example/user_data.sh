#!/bin/bash
sudo su -
layer=${name}
domainname=${domain}
pip=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)
hstname="$layer.$domainname"
echo "$pip $hstname $layer" | sudo tee -a /etc/hosts
echo "$hstname" | sudo tee /etc/hostname > /dev/null
hostname=`cat /etc/hostname`
sudo hostnamectl set-hostname $hostname

resolv_conf=$(cat <<-EOT
nameserver 10.37.110.248
nameserver 10.37.110.191
nameserver 10.37.0.2
options attempts:3 timeout:1
search ap-south-1.compute.internal
EOT
)
echo "$resolv_conf" > /etc/resolv.conf
